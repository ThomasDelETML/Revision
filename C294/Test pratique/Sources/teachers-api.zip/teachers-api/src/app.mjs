import express from "express";
import cors from "cors";

import { sequelize, initDb } from "./db/sequelize.mjs";

sequelize
  .authenticate()
  .then((_) =>
    console.log("La connexion à la base de données a bien été établie")
  )
  .catch((error) => console.error("Impossible de se connecter à la DB"));

// Initialiser la DB en chargeant les données
initDb();

// instanciation d'express
const app = express();

const corsOptions = {
  origin: true, // Votre frontend
  credentials: true, // Permet de recevoir les credentials (cookies, header d'authentification)
};

app.use(cors(corsOptions));

// définition du port du serveur web
// En production sur Heroku, le numéro de port sera donné par la variable d'environnement
const port = process.env.PORT || 3000;

// lorsqu'un client envoie une requête POST avec un corps de requête JSON
// bodyParser.json() convertit le JSON en un objet JavaScript
// Attention Body-parser est maintenant déprécié, il faut maintenant utiliser :
app.use(express.json());

// lie et écoute les connexions sur l’hôte et le port spécifiés
// http://expressjs.com/en/api.html#app.listen
app.listen(port, () =>
  console.log(
    `Notre application est démarrée à l'adresse : http://localhost:${port}`
  )
);

// définit une route pour l'URL /
// req pour la requête HTTP entrante
// res pour la réponse HTTP
app.get("/", (req, res) => {
  res.json("API teachers est disponible !");
});

/*
// Routes Sections
require("./src/routes/sections/findAllSections")(app);

// Routes Teachers
require("./src/routes/teachers/findAllTeachers")(app);
require("./src/routes/teachers/findTeacherByPk")(app);
require("./src/routes/teachers/createTeacher")(app);
require("./src/routes/teachers/updateTeacher")(app);
require("./src/routes/teachers/deleteTeacher")(app);

// Routes user
require("./src/routes/auth/login")(app);
*/

// Routes Sections
import { sectionsRouter } from "./routes/sections.mjs";
app.use("/api/sections", sectionsRouter);

// Routes Teachers
import { teachersRouter } from "./routes/teachers.mjs";
app.use("/api/teachers", teachersRouter);

// Routes user
import { loginRouter } from "./routes/login.mjs";
app.use("/api/auth/login", loginRouter);
