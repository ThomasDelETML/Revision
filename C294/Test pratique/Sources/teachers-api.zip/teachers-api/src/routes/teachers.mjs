import express from "express";
import { Teacher } from "../db/sequelize.mjs";
import { ValidationError, UniqueConstraintError, Op } from "sequelize";
import { auth } from "../auth/auth.mjs";

const teachersRouter = express();

teachersRouter.get("/", auth, (req, res) => {
  if (req.query.name) {
    const name = req.query.name;
    if (name.length < 2) {
      const message = `Le terme de recherche doit contenir au minimim 2 caractères.`;
      return res.status(400).json({ message });
    }
    const limit = parseInt(req.query.limit) || 5;
    return Teacher.findAndCountAll({
      where: {
        // name est la propriété du modèle teacher
        name: {
          // utilisation d'un opérateur sequelize LIKE
          [Op.like]: `%${name}%`, // name est le critère de la recherche
        },
      },
      order: ["name"],
      limit: limit,
    }).then(({ count, rows }) => {
      const message = `Il y a ${count} enseignants qui correspondent au terme de recherche ${name}`;
      res.json({ message, data: rows });
    });
  } else {
    // findAll retourne une promesse contenant la liste de tous les teachers
    Teacher.findAll({ order: ["name"] })
      .then((teachers) => {
        const message = "La liste des teachers a bien été récupérée !    ";
        //
        res.json({ message, data: teachers });
      })
      .catch((error) => {
        if (error instanceof ValidationError) {
          return res.status(400).json({ message: error.message, data: error });
        }
        const message = `La liste des enseignants n'a pas pu être récupérée ! Réessayez dans quelques instants.`;
        res.status(500).json({ message, data: error });
      });
  }
});

teachersRouter.get("/:id", auth, (req, res) => {
  const teacherId = req.params.id;
  // findByPk est une promesse
  Teacher.findByPk(teacherId)
    .then((teacher) => {
      if (teacher === null) {
        const message = `L'enseignant demandé n'existe pas. Réessayez avec un autre identifiant.`;
        // Attention au return qui permet interrompre le traitement en cours
        return res.status(404).json({ message });
      }
      const message = `Le teacher ${teacher.name} a bien été trouvé`;
      res.json({ message, data: teacher });
    })
    .catch((error) => {
      if (error instanceof ValidationError) {
        return res.status(400).json({ message: error.message, data: error });
      }
      const message = `L'enseignant n'a pas pu être récupéré ! Réessayez dans quelques instants.`;
      res.status(500).json({ message, data: error });
    });
});

teachersRouter.post("/", auth, (req, res) => {
  Teacher.create(req.body)
    .then((teacher) => {
      const message = `Le teacher ${teacher.name} a bien été créée !`;
      res.json({ message, data: teacher });
    })
    .catch((error) => {
      if (error instanceof ValidationError) {
        return res.status(400).json({ message: error.message, data: error });
      }
      if (error instanceof UniqueConstraintError) {
        return res.status(400).json({ message: error.message, data: error });
      }
      const message = `L'enseignant n'a pas pu être ajouté ! Réessayez dans quelques instants.`;
      res.status(500).json({ message, data: error });
    });
});

teachersRouter.put("/:id", auth, (req, res) => {
  //
  // On récupère l'id de l'URL
  const teacherId = req.params.id;

  // On met à jour le modèle (promesse)
  Teacher.update(
    //
    // On récupère le body de la requete
    req.body,

    // On identique l'id du teacher a mettre à jour
    { where: { id: teacherId } }
  )
    .then((_) => {
      // On récupère le teacher qui vient d'être mis a jour pour le message dans l'api REST
      // A noter que l'on utilise un return
      // ainsi en cas d'erreur c'est le catch de la promesse (then) parent
      // qui fera le traitement de l'erreur
      return Teacher.findByPk(teacherId).then((teacher) => {
        if (teacher === null) {
          const message = `L'enseignant n'a pas été trouvé`;
          return res.status(404).json({ message });
        }
        const message = `L'enseignant ${teacher.name} a bien été mis à jour !`;
        res.json({ message, data: teacher });
      });
    })
    .catch((error) => {
      if (error instanceof ValidationError) {
        return res.status(400).json({ message: error.message, data: error });
      }
      if (error instanceof UniqueConstraintError) {
        return res.status(400).json({ message: error.message, data: error });
      }
      const message = `L'enseignant n'a pas pu être modifié ! Réessayez dans quelques instants.`;
      res.status(500).json({ message, data: error });
    });
});

teachersRouter.delete("/:id", auth, (req, res) => {
  const teacherId = req.params.id;

  Teacher.findByPk(teacherId)
    .then((teacherToDeleted) => {
      if (teacherToDeleted === null) {
        const message = `L'enseignant demandé n'existe pas. Réessayez avec un autre identifiant`;
        return res.status(404).json({ message });
      }
      // A noter l'utilisation de return
      // en cas d'erreur l'erreur sera catch dans le parent
      return Teacher.destroy({
        where: {
          id: teacherToDeleted.id,
        },
      }).then((_) => {
        const message = `Le teacher ${teacherToDeleted.name} a bien été supprimé !`;
        res.json({ message, data: teacherToDeleted });
      });
    })
    .catch((error) => {
      if (error instanceof ValidationError) {
        return res.status(400).json({ message: error.message, data: error });
      }
      const message = `L'enseignant n'a pas pu être supprimé ! Réessayez dans quelques instants.`;
      res.status(500).json({ message, data: error });
    });
});

export { teachersRouter };
