import express from "express";
import { Section } from "../db/sequelize.mjs";
import { ValidationError, Op } from "sequelize";
import { auth } from "../auth/auth.mjs";

const sectionsRouter = express();

sectionsRouter.get("/", auth, (req, res) => {
  //
  // findAll retourne une promesse contenant la liste de toutes les sections
  Section.findAll()
    .then((sections) => {
      const message = "La liste des sections a bien été récupérée !    ";
      //
      res.json({ message, data: sections });
    })
    .catch((error) => {
      if (error instanceof ValidationError) {
        return res.status(400).json({ message: error.message, data: error });
      }
      const message = `La liste des sectons n'a pas pu être récupérée ! Réessayez dans quelques instants.`;
      res.status(500).json({ message, data: error });
    });
});

sectionsRouter.get("/:id", auth, (req, res) => {
  const sectionId = req.params.id;
  // findByPk est une promesse
  Section.findByPk(sectionId)
    .then((section) => {
      if (section === null) {
        const message = `La section demandée n'existe pas. Réessayez avec un autre identifiant.`;
        // Attention au return qui permet interrompre le traitement en cours
        return res.status(404).json({ message });
      }
      const message = `La section ${section.name} a bien été trouvée`;
      res.json({ message, data: section });
    })
    .catch((error) => {
      if (error instanceof ValidationError) {
        return res.status(400).json({ message: error.message, data: error });
      }
      const message = `La section n'a pas pu être récupérée ! Réessayez dans quelques instants.`;
      res.status(500).json({ message, data: error });
    });
});

export { sectionsRouter };
