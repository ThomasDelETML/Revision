import { Sequelize, DataTypes } from "sequelize";
import bcrypt from "bcrypt";

import { TeacherModel } from "../models/teacher.mjs";
import { SectionModel } from "../models/section.mjs";
import { UserModel } from "../models/user.mjs";
import { teachers } from "./mock-teacher.mjs";
import { sections } from "./mock-section.mjs";

let sequelize;

sequelize = new Sequelize(
  "db_etml_teachers", // Nom de la DB qui doit exister
  "root", // Nom de l'utilisateur
  "root", // Mot de passe de l'utilisateur
  {
    host: "localhost",
    dialect: "mysql",
    port: "6033",
    logging: false,
  }
);

// Le modèle teacher
const Teacher = TeacherModel(sequelize, DataTypes);

// Le modèle section
const Section = SectionModel(sequelize, DataTypes);

// Le modèle user
const User = UserModel(sequelize, DataTypes);

const initDb = () => {
  return sequelize
    .sync({ force: true }) // Force la synchro => donc supprime les données également
    .then((_) => {
      importTeachers();
      importSections();
      importUsers();
      console.log("La base de données db_teachers a bien été synchronisée");
    });
};

const importTeachers = () => {
  // import tous les teachers présents dans le fichier db/mock-teacher
  teachers.map((teacher) => {
    Teacher.create({
      firstname: teacher.firstname,
      name: teacher.name,
      gender: teacher.gender,
      nickname: teacher.nickname,
      origine: teacher.origine,
      fkSection: teacher.fkSection,
    }).then((teacher) => console.log(teacher.toJSON()));
  });
};

const importSections = () => {
  // import toutes les sections présentes dans le fichier db/mock-section
  sections.map((section) => {
    Section.create({
      name: section.name,
    }).then((section) => console.log(section.toJSON()));
  });
};

const importUsers = () => {
  bcrypt
    .hash("etml", 10) // temps pour hasher = du sel
    .then((hash) =>
      User.create({
        username: "etml",
        password: hash,
      })
    )
    .then((user) => console.log(user.toJSON()));
};

export { sequelize, initDb, Teacher, Section, User };
