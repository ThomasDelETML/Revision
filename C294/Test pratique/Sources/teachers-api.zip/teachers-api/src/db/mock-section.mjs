const sections = [
  {
    id: 1,
    name: "informatique",
    created: new Date(),
  },
  {
    id: 2,
    name: "automatique",
    created: new Date(),
  },
  {
    id: 3,
    name: "électronique",
    created: new Date(),
  },
  {
    id: 4,
    name: "polymécanique",
    created: new Date(),
  },
  {
    id: 5,
    name: "bois",
    created: new Date(),
  },
  {
    id: 6,
    name: "automobile",
    created: new Date(),
  },
];

export { sections };
