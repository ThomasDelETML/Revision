// https://sequelize.org/docs/v7/models/data-types/

const SectionModel = (sequelize, DataTypes) => {
  return sequelize.define(
    "Section",
    {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
      },
      name: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: {
          msg: "Ce nom est déjà pris.",
        },
      },
    },
    {
      timestamps: true,
      createdAt: "created",
      updatedAt: false,
    }
  );
};

export { SectionModel };
