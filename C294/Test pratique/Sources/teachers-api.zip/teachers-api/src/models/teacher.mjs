// https://sequelize.org/docs/v7/models/data-types/

const TeacherModel = (sequelize, DataTypes) => {
  return sequelize.define(
    "Teacher",
    {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
      },
      firstname: {
        type: DataTypes.STRING,
        allowNull: false,
        validate: {
          len: {
            args: [2, 25],
            msg: "Le prénom doit contenir entre 2 et 25 caractères.",
          },
          notEmpty: { msg: "Le prénom ne peut pas être vide." },
          notNull: { msg: "Le prénom est une propriété requise." },
        },
      },
      name: {
        type: DataTypes.STRING,
        allowNull: false,
        validate: {
          len: {
            args: [2, 25],
            msg: "Le nom doit contenir entre 2 et 25 caractères.",
          },
          notEmpty: { msg: "Le nom ne peut pas être vide." },
          notNull: { msg: "Le nom est une propriété requise." },
        },
      },
      gender: {
        type: DataTypes.CHAR,
        allowNull: false,
      },
      nickname: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: {
          msg: "Ce surnom est déjà pris.",
        },
        validate: {
          len: {
            args: [2, 25],
            msg: "Le surnom doit contenir entre 2 et 25 caractères.",
          },
          notEmpty: { msg: "Le surnom ne peut pas être vide." },
          notNull: { msg: "Le surnom est une propriété requise." },
        },
      },
      origine: {
        type: DataTypes.TEXT,
        allowNull: false,
      },
      fkSection: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
    },
    {
      timestamps: true,
      createdAt: "created",
      updatedAt: false,
    }
  );
};

export { TeacherModel };
