# teachers-api

## Installation en local

Se placer dans le répertoire teachers-api

Faire un `npm install`

Lancer l'application `npm run start`

Si vous utilisez l'environnement `docker` utilisé à l'ETML pour la db MySQL alors `npm run start-docker`
