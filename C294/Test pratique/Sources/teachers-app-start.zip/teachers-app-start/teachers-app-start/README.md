# teachers-app

L'application des surnoms des enseignants ! (Version 2)

L'idée est de n'utiliser que des concepts vues dans le cours de l'année 2024.
