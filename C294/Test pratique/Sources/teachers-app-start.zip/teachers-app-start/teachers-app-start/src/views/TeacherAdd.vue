<script setup>

</script>

<template>
  <main class="container">
    <div class="user-body">
      <form id="form">
        <h3>Ajout d'un nouvel enseignant</h3>
        <p>
          <input type="radio" id="genre1" name="genre" value="M" />
          <label for="genre1">Homme</label>
          <input type="radio" id="genre2" name="genre" value="F" />
          <label for="genre2">Femme</label>
          <input type="radio" id="genre3" name="genre" value="A" />
          <label for="genre3">Autre</label>
        </p>
        <p>
          <label for="firstName">Prénom :</label>
          <input type="text" id="firstName" />
        </p>
        <p>
          <label for="name">Nom :</label>
          <input type="text" id="name" />
        </p>
        <p>
          <label for="nickName">Surnom :</label>
          <input type="text" id="nickName" />
        </p>
        <p>
          <label for="origin">Origine :</label>
          <textarea name="origin" id="origin" ></textarea>
        </p>
        <p>
          <label style="display: none" for="section"></label>
          <select name="section" id="section" >
            <option value="">Section</option>
            <option>
              Informatique
            </option>
          </select>
        </p>
        <p>
          <input class="button" type="submit" value="Submit" />
          <button type="button">Effacer</button>
        </p>
      </form>
    </div>
    <div class="user-footer">
      <a href="index.html">Retour à la page d'accueil</a>
    </div>
  </main>
</template>
