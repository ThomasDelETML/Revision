<script setup>

</script>

<template>
  <main class="container">
    <h3>Liste des enseignants</h3>
    <form action="#" method="post">
      <table>
        <thead>
          <tr>
            <th>Nom</th>
            <th>Surnom</th>
            <th>Options</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>Charmier Grégory</td>
            <td>GregLeBarbar</td>
            <td class="containerOptions">
              <a>
                <img height="20em" src="../assets/img/delete.png" alt="delete" />
              </a>
              <a>
                <img height="20em" src="../assets/img/detail.png" alt="detail" />
              </a>
            </td>
          </tr>
        </tbody>
      </table>
    </form>
  </main>
</template>
