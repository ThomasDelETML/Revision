<script setup>

</script>

<template>
  <main class="container">
    <div class="user-head">
      <h3>
        Détail : Charmier Grégory
        <img
          style="margin-left: 1vw"
          height="20em"
          src="../assets/img/male.png"
          alt="male symbole"
        />
      </h3>
      <p>Section: Informatique</p>
      <div class="actions">
        <a>
          <img height="20em" src="../assets/img/delete.png" alt="delete icon" />
        </a>
      </div>
    </div>
    <div class="user-body">
      <div class="left">
        <p>Surnom : GregLeBarbar</p>
        <p>
          Origine : <br />
          Plateforme de jeux d'échecs en ligne
        </p>
      </div>
    </div>
    <div class="user-footer">
      <a> Retour à la page d'accueil </a>
    </div>
  </main>
</template>
