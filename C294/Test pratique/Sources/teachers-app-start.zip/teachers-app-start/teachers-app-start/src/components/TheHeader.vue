<script setup></script>

<template>
  <header>
    <div class="container-header">
      <div class="titre-header">
        <h1>Surnom des enseignants</h1>
      </div>
    </div>
    <nav>
      <h2>Zone pour le menu</h2>
      <a>Accueil</a> |
      <a>Ajouter un nouvel enseignant</a>
    </nav>
  </header>
</template>
