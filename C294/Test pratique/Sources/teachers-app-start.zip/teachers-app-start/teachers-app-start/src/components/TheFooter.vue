<template>
  <footer>
    <p>Copyright GCR - bulle web-db - 2024</p>
  </footer>
</template>
