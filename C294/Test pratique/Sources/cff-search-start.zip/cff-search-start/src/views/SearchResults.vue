<template>

</template>

<script setup>

const connections = JSON.parse(route.query.data)

</script>

<style scoped>

</style>
