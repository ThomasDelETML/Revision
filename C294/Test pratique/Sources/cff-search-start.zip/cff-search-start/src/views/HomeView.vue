<template>

</template>

<script setup>

const fromStation = // ... à compléter
const toStation = // ... à compléter

async function searchTrains() {
  try {

    const response = await axios.get(`https://transport.opendata.ch/v1/connections`, {
      params: {
        from: fromStation.value,
        to: toStation.value
      }
    })

    router.push({
      name: 'SearchResults',
      query: { data: JSON.stringify(response.data.connections) }
    })
  } catch (error) {
    console.error('Failed to fetch train data:', error)
    alert('Erreur lors de la recherche des connexions.')
  }
}

</script>

<style scoped>

</style>
