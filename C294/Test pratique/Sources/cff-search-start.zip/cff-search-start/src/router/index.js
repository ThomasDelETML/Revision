// router/index.js
import { createRouter, createWebHistory } from 'vue-router'

const routes = [
  /* A vous de compléter ici */
]

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes
})

export default router
