const app = Vue.createApp({
  data() {
    return {
      // A compléter
    };
  },
  methods: {
    // A compléter
  },
});
